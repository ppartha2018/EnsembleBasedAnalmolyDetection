anomdet
========

This is a simple Python module which collects various anomaly/outlier/novelty
detection algorithms.

## Dependencies

* scikit-learn