from .knn import KNN
from .lof import LOF
from .cof import COF
from .loop import LoOP