# Import everything in this folder!!
#import os

#for f in os.listdir('.'):
#    if f[-3:] == '.py':
#        exec('from %s import *' % f[:-3])

from GAOutlierEnsemble import GAOutlierEnsemble
from distance_to_random_points import DistanceToRandomPoints