from ...datasets import load_pendigits

def test_pendigits():
    '''
    Test that load_pendigits works.
    '''
    dat = load_pendigits()