class BenchmarkResult(object):
    '''
    A class to store benchmark results.
    '''
    
    pass